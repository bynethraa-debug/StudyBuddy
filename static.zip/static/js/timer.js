// =========================
// POMODORO SETTINGS
// =========================

let studyMinutes = 25;
let shortBreak = 5;
let longBreak = 15;

let totalPomodoros = 4;
let currentPomodoro = 1;

let mode = "study";

let timeLeft = studyMinutes * 60;

let timer = null;
let running = false;

// =========================
// ELEMENTS
// =========================

const timerDisplay = document.getElementById("timer");

const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const resetBtn = document.getElementById("resetBtn");

const pomodoroCounter = document.querySelector(".pomodoro-count");

// =========================
// DISPLAY
// =========================

function updateDisplay(){

    let minutes = Math.floor(timeLeft / 60);

    let seconds = timeLeft % 60;

    timerDisplay.textContent =
        `${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;

}

updateDisplay();

// =========================
// START
// =========================

startBtn.onclick = () => {

    if(running) return;

    running = true;

    timer = setInterval(countdown,1000);

};

// =========================
// PAUSE
// =========================

pauseBtn.onclick = () => {

    clearInterval(timer);

    running = false;

};

// =========================
// RESET
// =========================

resetBtn.onclick = () => {

    clearInterval(timer);

    running = false;

    if(mode==="study"){

        timeLeft = studyMinutes*60;

    }else if(mode==="short"){

        timeLeft = shortBreak*60;

    }else{

        timeLeft = longBreak*60;

    }

    updateDisplay();

};

// =========================
// COUNTDOWN
// =========================

function countdown(){

    if(timeLeft>0){

        timeLeft--;

        updateDisplay();

        return;

    }

    clearInterval(timer);

    running=false;

    switchMode();

}

// =========================
// SWITCH MODES
// =========================

function switchMode(){

    if(mode==="study"){

        if(currentPomodoro===totalPomodoros){

            mode="long";

            timeLeft=longBreak*60;

            alert("🎉 Great job! Time for a long break.");

            currentPomodoro=1;

        }else{

            mode="short";

            timeLeft=shortBreak*60;

            alert("☕ Time for a short break!");

        }

    }

    else if(mode==="short"){

        mode="study";

        currentPomodoro++;

        timeLeft=studyMinutes*60;

    }

    else{

        mode="study";

        timeLeft=studyMinutes*60;

    }

    pomodoroCounter.innerHTML =
        `🌿 Pomodoro ${currentPomodoro} / ${totalPomodoros}`;

    updateDisplay();

}